# SHMS-Frontend

## Front end for the Smart Home Monitoring System
